HOSPITAL MANAGEMENT SYSTEM - JAVA SPRING BOOT
==============================================

FEATURES
- Patient registration and login
- Doctor dashboard with specialties, fees, location and timings
- Appointment booking form
- Appointment history for the logged-in patient
- Prevents two bookings for the same doctor/date/time in this single running application
- Responsive interface styled to match the reference screenshots

REQUIREMENTS
- JDK 17 or later
- Maven 3.6+ (or use Maven support in your IDE)
- Internet connection for the first Maven build to download dependencies

RUN IN ECLIPSE
1. Extract the ZIP file.
2. Open Eclipse.
3. Choose File > Import > Maven > Existing Maven Projects.
4. Browse to the extracted HospitalManagementSystem folder.
5. Select its pom.xml and click Finish.
6. Wait for Maven dependencies to finish downloading.
7. Open src/main/java/com/example/hospital/HospitalManagementApplication.java.
8. Right-click the file > Run As > Java Application (or Spring Boot App if available).
9. Open http://localhost:8080/register.html in your browser.

RUN FROM TERMINAL
1. Open a terminal in the extracted project folder.
2. Run: mvn spring-boot:run
3. Open http://localhost:8080/register.html

IMPORTANT PROJECT NOTES
- This is a learning/demo project. Users and appointments are stored in memory and will reset when the application restarts.
- Passwords are plain text in this starter demo; do not use real passwords or deploy it publicly. For a real application, use Spring Security and BCrypt password hashing.
- Appointment uniqueness is synchronized inside one application process. A production multi-instance deployment needs a persistent database transaction and a database unique constraint/locking strategy.
- Payment, email/SMS, administrator tools, medical records, and deployment configuration are not included.
