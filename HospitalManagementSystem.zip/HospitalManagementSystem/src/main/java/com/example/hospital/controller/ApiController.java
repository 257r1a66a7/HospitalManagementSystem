package com.example.hospital.controller;

import com.example.hospital.model.Appointment;
import com.example.hospital.service.HospitalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final HospitalService service;
    public ApiController(HospitalService service) { this.service = service; }
    @PostMapping("/register") public Map<String,Object> register(@RequestBody Map<String,String> body) {
        boolean ok = service.register(body.get("name"), body.get("username"), body.get("password"));
        if (!ok) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please enter valid details and use a new username. Password must be at least 4 characters.");
        return Map.of("message", "Account created successfully. Please log in.");
    }
    @PostMapping("/login") public Map<String,Object> login(@RequestBody Map<String,String> body, HttpSession session) {
        if (!service.login(body.get("username"), body.get("password"))) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password.");
        String username = body.get("username").trim().toLowerCase(); session.setAttribute("username", username);
        return Map.of("message", "Login successful", "username", username);
    }
    @PostMapping("/logout") public Map<String,String> logout(HttpSession session) { session.invalidate(); return Map.of("message", "Logged out"); }
    @GetMapping("/me") public Map<String,String> me(HttpSession session) { return Map.of("username", requireUser(session)); }
    @GetMapping("/doctors") public Object doctors(HttpSession session) { requireUser(session); return service.doctors(); }
    @PostMapping("/appointments") public Appointment book(@RequestBody Map<String,String> body, HttpSession session) {
        String username = requireUser(session);
        try { return service.book(username, Long.parseLong(body.get("doctorId")), body.get("date"), body.get("time")); }
        catch (IllegalArgumentException e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage()); }
        catch (IllegalStateException e) { throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage()); }
    }
    @GetMapping("/appointments") public Object history(HttpSession session) { return service.history(requireUser(session)); }
    private String requireUser(HttpSession session) {
        Object username = session.getAttribute("username");
        if (username == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in first.");
        return username.toString();
    }
}
