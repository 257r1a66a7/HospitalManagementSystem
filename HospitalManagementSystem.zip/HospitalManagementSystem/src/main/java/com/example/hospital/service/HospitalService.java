package com.example.hospital.service;

import com.example.hospital.model.Appointment;
import com.example.hospital.model.Doctor;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class HospitalService {
    private final Map<String, String> users = new ConcurrentHashMap<>();
    private final List<Doctor> doctors = List.of(
        new Doctor(1,"Dr. Ananya Sharma","Cardiologist","Hyderabad",700,"10:00 AM – 1:00 PM","AS"),
        new Doctor(2,"Dr. Rahul Verma","Dermatologist","Hyderabad",500,"11:00 AM – 2:00 PM","RV"),
        new Doctor(3,"Dr. Meera Reddy","Pediatrician","Hyderabad",600,"9:00 AM – 12:00 PM","MR"),
        new Doctor(4,"Dr. Arjun Rao","Orthopedic","Hyderabad",800,"4:00 PM – 7:00 PM","AR"),
        new Doctor(5,"Dr. Priya Nair","Neurologist","Hyderabad",900,"10:00 AM – 1:00 PM","PN"),
        new Doctor(6,"Dr. Kiran Kumar","General Physician","Hyderabad",400,"9:00 AM – 1:00 PM","KK")
    );
    private final List<Appointment> appointments = Collections.synchronizedList(new ArrayList<>());
    private final Set<String> reservedSlots = ConcurrentHashMap.newKeySet();
    private final AtomicLong nextId = new AtomicLong(1001);

    public boolean register(String name, String username, String password) {
        if (name == null || name.isBlank() || username == null || username.isBlank() || password == null || password.length() < 4) return false;
        return users.putIfAbsent(username.trim().toLowerCase(), password) == null;
    }
    public boolean login(String username, String password) {
        return username != null && password != null && password.equals(users.get(username.trim().toLowerCase()));
    }
    public List<Doctor> doctors() { return doctors; }
    public synchronized Appointment book(String username, long doctorId, String date, String time) {
        Doctor doctor = doctors.stream().filter(d -> d.id() == doctorId).findFirst().orElse(null);
        if (doctor == null) throw new IllegalArgumentException("Doctor not found.");
        if (date == null || date.isBlank() || time == null || time.isBlank()) throw new IllegalArgumentException("Choose a date and time slot.");
        String key = doctorId + "|" + date + "|" + time;
        if (!reservedSlots.add(key)) throw new IllegalStateException("This appointment slot has already been booked. Please choose another slot.");
        Appointment a = new Appointment(nextId.getAndIncrement(), username, doctorId, doctor.name(), date, time, "CONFIRMED");
        appointments.add(a);
        return a;
    }
    public List<Appointment> history(String username) {
        synchronized (appointments) { return appointments.stream().filter(a -> a.username().equals(username)).toList(); }
    }
}
