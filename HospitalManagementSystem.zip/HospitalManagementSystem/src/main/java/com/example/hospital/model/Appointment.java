package com.example.hospital.model;

public record Appointment(long id, String username, long doctorId, String doctorName, String date, String time, String status) {}
