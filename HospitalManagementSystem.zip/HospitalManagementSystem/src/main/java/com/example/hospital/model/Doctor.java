package com.example.hospital.model;

public record Doctor(long id, String name, String specialty, String location, int fee, String hours, String initials) {}
